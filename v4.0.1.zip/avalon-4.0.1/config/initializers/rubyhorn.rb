Rubyhorn.init
