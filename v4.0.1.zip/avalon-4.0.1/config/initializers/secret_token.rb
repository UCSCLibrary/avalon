# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Avalon::Application.config.secret_token = '1dec111de07690d5e60d72104ef2d85103fa654aac7d9a7507ae030bc3de1850ea8bfa5ca3b358950165300c7944917c44a1486978efb8704edf66524e3da24c'
