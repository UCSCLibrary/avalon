require 'susy'
project_type = :rails
